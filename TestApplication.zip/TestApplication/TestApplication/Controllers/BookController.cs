﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using System;
using System.IO;
using System.Xml.Linq;
using TestApplication.Models;
using System.Data;
using System.Xml;

public class HomeController : Controller
{
    private readonly AppDbContext _context;
    private IWebHostEnvironment _WebHostEnvironment;

    public HomeController(AppDbContext context, IWebHostEnvironment webHostEnvironment)
    {
        _context = context;
        _WebHostEnvironment = webHostEnvironment;
    }
    
    public IActionResult Index()
    {
        List<Person> persons = new List<Person>();  
        XmlDocument document = new XmlDocument();


        document.Load(string.Concat(this._WebHostEnvironment.WebRootPath,"/data.xml"));

        foreach (XmlNode node in document.SelectNodes("/People/Person"))
        {
            persons.Add(new Person
            {

                Id = int.Parse(node["Id"].InnerText),
                Name = node["Name"].InnerText,
                Age = int.Parse(node["Age"].InnerText)

            });
           
        }
        foreach (var item in persons)
        {
            Person p = new Person();
            //p.Id = item.Id;
            p.Name = item.Name;
            p.Age = item.Age;
            _context.Add(p);

        }
        _context.SaveChanges();
        //ViewBag.Data=persons;
        return View(persons);
    }

    //public Task<IActionResult>AddData()
    //{
    //    return View();
    //}

    
    

   
}


